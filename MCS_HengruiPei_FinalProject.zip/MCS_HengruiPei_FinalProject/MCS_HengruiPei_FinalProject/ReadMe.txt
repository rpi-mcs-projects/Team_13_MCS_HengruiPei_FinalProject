How to use this simulation code package?
Running two main files Main_dist2EE.m and Main_T2EE.m.

Any special software required, software version, toolbox？
MATLAB CVX toolbox required. It can be downloaded from this website: https://cvxr.com/cvx/

Run time of the code
Note that it may cost much time for simulation, more than 6 hours(depend on the hardware).